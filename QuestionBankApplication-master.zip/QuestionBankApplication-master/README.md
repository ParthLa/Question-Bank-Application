# QuestionBankApplication

run using python3 manage.py runserver
Username : sunil
Password : 1234$#@!